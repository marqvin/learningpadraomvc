package br.com.mesa22.padraomvcmesa22;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Padraomvcmesa22ApplicationTests {

	@Test
	void contextLoads() {
	}

}
