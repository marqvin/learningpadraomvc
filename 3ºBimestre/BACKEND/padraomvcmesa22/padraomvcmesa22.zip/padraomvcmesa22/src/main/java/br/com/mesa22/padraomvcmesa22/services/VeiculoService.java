package br.com.mesa22.padraomvcmesa22.services;

import br.com.mesa22.padraomvcmesa22.entities.Veiculo;

import java.util.List;

public interface VeiculoService {
    List<Veiculo> listVeiculo();

}
