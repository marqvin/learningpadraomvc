package br.com.mesa22.padraomvcmesa22;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Padraomvcmesa22Application {

	public static void main(String[] args) {
		SpringApplication.run(Padraomvcmesa22Application.class, args);
	}

}
